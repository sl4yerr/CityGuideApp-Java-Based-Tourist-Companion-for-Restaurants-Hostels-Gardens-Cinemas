package hotel.review.appandroid;

import android.content.Intent;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_2);

        CardView boxCinema = findViewById(R.id.box_cinema);
        CardView boxGarden = findViewById(R.id.box_garden);
        CardView boxRestaurant = findViewById(R.id.box_restaurant);
        CardView boxHotel = findViewById(R.id.box_hotel);

        boxCinema.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity_2.this, MainActivity_C.class);
            startActivity(intent);
        });

        boxGarden.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity_2.this, MainActivity_G.class);
            startActivity(intent);
        });

        boxRestaurant.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity_2.this, MainActivity_R.class);
            startActivity(intent);
        });

        boxHotel.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity_2.this, MainActivity_H.class);
            startActivity(intent);
        });
    }
}
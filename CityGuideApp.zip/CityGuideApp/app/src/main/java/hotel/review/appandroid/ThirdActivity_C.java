package hotel.review.appandroid;

import android.app.ActivityOptions;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.getbase.floatingactionbutton.FloatingActionButton;

public class ThirdActivity_C extends AppCompatActivity {

    ImageView down_arrow;
    ScrollView third_scrollview;
    Animation from_bottom;
    FloatingActionButton btnCall, btnMessage, btnEmail, btnLocation, btnTranslate;
    private boolean isTranslated = false;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_c);

        // Initialize views
        down_arrow = findViewById(R.id.down_arrow);
        third_scrollview = findViewById(R.id.third_scrillview);
        btnCall = findViewById(R.id.btnCall);
        btnMessage = findViewById(R.id.btnMessage);
        btnEmail = findViewById(R.id.btnEmail);
        btnLocation = findViewById(R.id.btnLocation);
        btnTranslate = findViewById(R.id.btnTranslate);

        // Set up animations
        from_bottom = AnimationUtils.loadAnimation(this, R.anim.anim_from_bottom);
        down_arrow.setAnimation(from_bottom);
        third_scrollview.setAnimation(from_bottom);

        // Fullscreen setup
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        // Set click listeners
        down_arrow.setOnClickListener(view -> {
            Intent intent = new Intent(ThirdActivity_C.this, SecondActivity_C.class);
            Pair[] pairs = new Pair[1];
            pairs[0] = new Pair<View, String>(down_arrow, "background_image_transition");
            ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(ThirdActivity_C.this, pairs);
            startActivity(intent, options.toBundle());
        });

        btnCall.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:+213123456789"));
            startActivity(intent);
        });

        btnMessage.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("sms:+213123456789"));
            intent.putExtra("sms_body", "Hi there!");
            startActivity(intent);
        });

        btnEmail.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:someone@example.com"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Subject here");
            intent.putExtra(Intent.EXTRA_TEXT, "Message body here");
            startActivity(Intent.createChooser(intent, "Send Email"));
        });

        btnLocation.setOnClickListener(view -> {
            try {
                String uri = "geo:36.751101100399204,2.9521914535170684?q=36.751101100399204,2.9521914535170684(TMV+Cinema)";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                intent.setPackage("com.google.android.apps.maps");
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    String webUrl = "https://www.google.com/maps/search/?api=1&query=36.751101100399204,2.9521914535170684";
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(webUrl));
                    startActivity(browserIntent);
                }
            } catch (Exception e) {
                Toast.makeText(this, "Couldn't open maps", Toast.LENGTH_SHORT).show();
                Log.e("Maps", "Error opening maps", e);
            }
        });

        btnTranslate.setOnClickListener(view -> {
            TextView thirdTitle = findViewById(R.id.third_title);
            TextView aboutText = findViewById(R.id.about_text);
            TextView venueTypeText = findViewById(R.id.venue_type_text);
            TextView typeOfViewText = findViewById(R.id.type_of_view_text);

            if (!isTranslated) {
                // Translate to Arabic
                thirdTitle.setText("سينما تي إم في");
                aboutText.setText("تعد سينما تي إم في أول مجمع سينمائي في الجزائر العاصمة، يقع في جاردن سيتي مول. يتميز بأحدث أنظمة العرض والصوت، ومقاعد مريحة، واختيار من أحدث الأفلام الدولية والمحلية. يجذب تصميمه الأنيق ومرافقه عشاق السينما الباحثين عن ترفيه عالي الجودة في إطار عصري.");
                venueTypeText.setText("سينما");
                typeOfViewText.setText("مجمع سينمائي حديث يقدم تجربة مشاهدة أفلام مميزة.");
            } else {
                // Revert to English
                thirdTitle.setText("TMV Cinema");
                aboutText.setText("TMV Cinema is Algiers' first cinema complex, located in Garden City Mall. It features state-of-the-art projection and sound systems, comfortable seating, and a selection of the latest international and local films. The cinema's sleek design and amenities make it a popular destination for movie enthusiasts seeking quality entertainment in a contemporary setting.");
                venueTypeText.setText("Cinema");
                typeOfViewText.setText("A modern multiplex offering a premium movie-going experience.");
            }
            isTranslated = !isTranslated;
        });
    }
}
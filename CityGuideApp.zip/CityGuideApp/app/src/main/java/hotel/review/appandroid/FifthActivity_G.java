package hotel.review.appandroid;

import android.app.ActivityOptions;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;

public class FifthActivity_G extends AppCompatActivity {

    ImageView down_arrow;
    ScrollView third_scrollview;
    Animation from_bottom;

    // FAB declarations
    FloatingActionButton btnCall, btnMessage, btnEmail, btnLocation, btnTranslate;
    FloatingActionsMenu fabMenu;
    private boolean isTranslated = false;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth_g);

        down_arrow = findViewById(R.id.down_arrow);
        third_scrollview = findViewById(R.id.third_scrillview);

        // Initialize FABs
        fabMenu = findViewById(R.id.fab_menu);
        btnCall = findViewById(R.id.btnCall);
        btnMessage = findViewById(R.id.btnMessage);
        btnEmail = findViewById(R.id.btnEmail);
        btnLocation = findViewById(R.id.btnLocation);
        btnTranslate = findViewById(R.id.btnTranslate);

        from_bottom = AnimationUtils.loadAnimation(this, R.anim.anim_from_bottom);

        down_arrow.setAnimation(from_bottom);
        third_scrollview.setAnimation(from_bottom);

        // Hide status bar and navigation bar
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        down_arrow.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FifthActivity_G.this, FourthActivity_G.class);
                Pair[] pairs = new Pair[1];
                pairs[0] = new Pair<View, String>(down_arrow, "background_image_transition");
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(FifthActivity_G.this, pairs);
                startActivity(intent, options.toBundle());
            }
        });

        // Standard FAB implementations
        btnCall.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:+213123456789")); // Same number
            startActivity(intent);
        });

        btnMessage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("sms:+213123456789"));
            intent.putExtra("sms_body", "Hi there!"); // Same message
            startActivity(intent);
        });

        btnEmail.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:contact@garden.com")); // Garden-specific
            intent.putExtra(Intent.EXTRA_SUBJECT, "Garden Visit Inquiry");
            intent.putExtra(Intent.EXTRA_TEXT, "Dear Garden,\n\n");
            startActivity(Intent.createChooser(intent, "Send Email"));
        });

        btnLocation.setOnClickListener(v -> {
            try {
                // Garden-specific coordinates
                String uri = "geo:36.7500,3.0833?q=Jardin+d'Essai+du+Hamma";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                intent.setPackage("com.google.android.apps.maps");

                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    // Fallback
                    String webUrl = "https://www.google.com/maps/search/?api=1&query=36.7500,3.0833";
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)));
                }
            } catch (Exception e) {
                Toast.makeText(FifthActivity_G.this, "Couldn't open maps", Toast.LENGTH_SHORT).show();
            }
        });

        // Translate button implementation
        btnTranslate.setOnClickListener(v -> {
            toggleTranslation();
        });
    }

    private void toggleTranslation() {
        TextView thirdTitle = findViewById(R.id.third_title);
        TextView aboutText = findViewById(R.id.about_text);
        TextView venueTypeText = findViewById(R.id.venue_type_text);
        TextView typeOfViewText = findViewById(R.id.type_of_view_text);
        TextView aboutLabel = findViewById(R.id.about);
        TextView venueTypeLabel = findViewById(R.id.venue_type);
        TextView typeOfViewLabel = findViewById(R.id.type_of_view);

        if (!isTranslated) {
            // Translate to Arabic
            thirdTitle.setText("حديقة ساعة الزهور");
            aboutText.setText("تقع حديقة ساعة الزهور في قلب الجزائر بالقرب من حديقة التجارب، وهي ساعة زهور جميلة مصنوعة من الأزهار الموسمية النابضة بالحياة. بُنيت خلال الحقبة الاستعمارية الفرنسية، الساعة العاملة هي عرض للبستنة ورمز لأناقة المدينة التاريخية، تجذب الزوار لالتقاط الصور والتنزه السلمي.");
            venueTypeText.setText("حديقة");
            typeOfViewText.setText("منظر طبيعي خلاب مع أزهار، مع إطلالة بانورامية على الساعة الزهرية المركزية، محاطة بمساحات خضراء مهذبة وأشجار النخيل - مثالية للتنزه السلمي أو الصور الخلابة.");
            aboutLabel.setText("حول");
            venueTypeLabel.setText("نوع المكان");
            typeOfViewLabel.setText("نوع المنظر");
        } else {
            // Revert to English
            thirdTitle.setText("Flower Clock Garden");
            aboutText.setText("Nestled in the heart of Algiers near the Jardin d'Essai, the Flower Clock Garden is a charming floral timepiece crafted with vibrant seasonal blooms. Built during the French colonial era, the functioning clock is both a horticultural display and a symbol of the city's historic elegance, attracting visitors for photos and peaceful strolls.");
            venueTypeText.setText("Garden");
            typeOfViewText.setText("A picturesque, floral landscape with a panoramic view of the blooming clock centerpiece, surrounded by well-manicured greenery and framed by palm trees—perfect for a peaceful stroll or scenic photos.");
            aboutLabel.setText("About");
            venueTypeLabel.setText("Venue Type");
            typeOfViewLabel.setText("Type of View");
        }
        isTranslated = !isTranslated;
    }
}
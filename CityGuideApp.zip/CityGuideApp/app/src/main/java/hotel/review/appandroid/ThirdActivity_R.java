package hotel.review.appandroid;

import android.app.ActivityOptions;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;

public class ThirdActivity_R extends AppCompatActivity {

    ImageView down_arrow;
    ScrollView third_scrollview;
    Animation from_bottom;
    FloatingActionButton btnCall, btnMessage, btnEmail, btnLocation, btnTranslate;
    FloatingActionsMenu fabMenu;
    private boolean isTranslated = false;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_r);

        down_arrow = findViewById(R.id.down_arrow);
        third_scrollview = findViewById(R.id.third_scrillview);

        // Initialize FABs
        fabMenu = findViewById(R.id.fab_menu);
        btnCall = findViewById(R.id.btnCall);
        btnMessage = findViewById(R.id.btnMessage);
        btnEmail = findViewById(R.id.btnEmail);
        btnLocation = findViewById(R.id.btnLocation);
        btnTranslate = findViewById(R.id.btnTranslate);

        from_bottom = AnimationUtils.loadAnimation(this, R.anim.anim_from_bottom);
        down_arrow.setAnimation(from_bottom);
        third_scrollview.setAnimation(from_bottom);

        //Hide status bar and navigation bar at the bottom
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        down_arrow.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ThirdActivity_R.this, SecondActivity_R.class);
                Pair[] pairs = new Pair[1];
                pairs[0] = new Pair<View, String>(down_arrow, "background_image_transition");
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(ThirdActivity_R.this, pairs);
                startActivity(intent, options.toBundle());
            }
        });

        // Set up FAB click listeners
        btnCall.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:+213123456789"));
            startActivity(intent);
        });

        btnMessage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("sms:+213123456789"));
            intent.putExtra("sms_body", "Hi there!");
            startActivity(intent);
        });

        btnEmail.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:contact@restaurant.com"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Reservation Inquiry");
            intent.putExtra(Intent.EXTRA_TEXT, "Dear Restaurant,\n\n");
            startActivity(Intent.createChooser(intent, "Send Email"));
        });

        btnLocation.setOnClickListener(v -> {
            try {
                String uri = "geo:36.7525,3.0424?q=Le+Père+Jego";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                intent.setPackage("com.google.android.apps.maps");

                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    String webUrl = "https://www.google.com/maps/search/?api=1&query=36.7525,3.0424";
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)));
                }
            } catch (Exception e) {
                Toast.makeText(ThirdActivity_R.this, "Couldn't open maps", Toast.LENGTH_SHORT).show();
            }
        });

        btnTranslate.setOnClickListener(v -> {
            TextView thirdTitle = findViewById(R.id.third_title);
            TextView aboutText = findViewById(R.id.about_text);
            TextView venueTypeText = findViewById(R.id.venue_type_text);
            TextView typeOfViewText = findViewById(R.id.type_of_view_text);

            if (!isTranslated) {
                // Translate to Arabic
                thirdTitle.setText("مطعم لو بير جيجو");
                aboutText.setText("يقع مطعم لو بير جيجو في حي الأبيار، ويقدم تجربة طهي راقية متخصصة في المأكولات الفرنسية. يوفر المطعم أجواء رومانسية بإطلالة بانورامية على خليج الجزائر. يتمتع الزوار بقائمة نبيذ واسعة وأطباق محضرة بمهارة، مما يجعله خيارًا مثاليًا للمناسبات الخاصة.");
                venueTypeText.setText("مطعم");
                typeOfViewText.setText("وجبات فرنسية أنيقة مع إطلالات بانورامية على الخليج.");
            } else {
                // Revert to English
                thirdTitle.setText("Le Père Jego");
                aboutText.setText("Located in El Biar, Le Père Jego offers a refined culinary experience, specializing in French gastronomy. The restaurant's elegant setting and panoramic views of the Bay of Algiers create a romantic ambiance. Guests can enjoy an extensive wine list and expertly crafted dishes, making it a top choice for special occasions.");
                venueTypeText.setText("Restaurant");
                typeOfViewText.setText("Elegant French dining with panoramic bay views.");
            }
            isTranslated = !isTranslated;
        });
    }
}
package hotel.review.appandroid;

import android.app.ActivityOptions;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;

public class ThirdActivity_G extends AppCompatActivity {

    ImageView down_arrow;
    ScrollView third_scrollview;
    Animation from_bottom;
    FloatingActionButton btnCall, btnMessage, btnEmail, btnLocation, btnTranslate;
    FloatingActionsMenu fabMenu;
    private boolean isTranslated = false;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_g);

        down_arrow = findViewById(R.id.down_arrow);
        third_scrollview = findViewById(R.id.third_scrillview);

        // Initialize FABs
        fabMenu = findViewById(R.id.fab_menu);
        btnCall = findViewById(R.id.btnCall);
        btnMessage = findViewById(R.id.btnMessage);
        btnEmail = findViewById(R.id.btnEmail);
        btnLocation = findViewById(R.id.btnLocation);
        btnTranslate = findViewById(R.id.btnTranslate);

        from_bottom = AnimationUtils.loadAnimation(this, R.anim.anim_from_bottom);
        down_arrow.setAnimation(from_bottom);
        third_scrollview.setAnimation(from_bottom);

        //Hide status bar and navigation bar at the bottom
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        down_arrow.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ThirdActivity_G.this, SecondActivity_G.class);
                Pair[] pairs = new Pair[1];
                pairs[0] = new Pair<View, String>(down_arrow, "background_image_transition");
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(ThirdActivity_G.this, pairs);
                startActivity(intent, options.toBundle());
            }
        });

        // Set up FAB click listeners
        btnCall.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:+213123456789"));
            startActivity(intent);
        });

        btnMessage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("sms:+213123456789"));
            intent.putExtra("sms_body", "Hi there!");
            startActivity(intent);
        });

        btnEmail.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:contact@garden.com"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Garden Visit Inquiry");
            intent.putExtra(Intent.EXTRA_TEXT, "Dear Jardin d'Essai,\n\n");
            startActivity(Intent.createChooser(intent, "Send Email"));
        });

        btnLocation.setOnClickListener(v -> {
            try {
                String uri = "geo:36.7500,3.0833?q=Jardin+d'Essai+du+Hamma";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                intent.setPackage("com.google.android.apps.maps");

                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    String webUrl = "https://www.google.com/maps/search/?api=1&query=36.7500,3.0833";
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)));
                }
            } catch (Exception e) {
                Toast.makeText(ThirdActivity_G.this, "Couldn't open maps", Toast.LENGTH_SHORT).show();
            }
        });

        btnTranslate.setOnClickListener(v -> {
            TextView thirdTitle = findViewById(R.id.third_title);
            TextView aboutText = findViewById(R.id.about_text);
            TextView venueTypeText = findViewById(R.id.venue_type_text);
            TextView typeOfViewText = findViewById(R.id.type_of_view_text);

            if (!isTranslated) {
                // Translate to Arabic
                thirdTitle.setText("حديقة التجارب بالحامة");
                aboutText.setText("تقع حديقة التجارب بالحامة في حي بلوزداد بالجزائر العاصمة، وهي حديقة نباتية مساحتها 32 هكتارًا تأسست عام 1832. تحتوي على مجموعة متنوعة من أكثر من 1200 نوع نباتي من جميع أنحاء العالم، مرتبة في أقسام مصممة بدقة تشمل حديقة على الطراز الفرنسي وحديقة على الطراز الإنجليزي. تضم الحديقة أيضًا حديقة حيوانات صغيرة وتوفر مناظر خلابة لخليج الجزائر. تعتبر واحدة من أهم الحدائق النباتية في العالم.");
                venueTypeText.setText("حديقة");
                typeOfViewText.setText("تقدم حديقة التجارب بالحامة مشهدًا بانوراميًا خصبًا مليئًا بالنباتات الاستوائية والمتوسطية، مع إطلالة على العمارة البيضاء للجزائر والخليج القريب. إنها واحة سلام تمزج بين الطبيعة وسحر المدينة.");
            } else {
                // Revert to English
                thirdTitle.setText("Jardin d'Essai du Hamma");
                aboutText.setText("Located in the Belouizdad district of Algiers, the Jardin d'Essai du Hamma is a 32-hectare botanical garden established in 1832. It features a diverse collection of over 1,200 plant species from around the world, arranged in beautifully landscaped sections including a French garden and an English garden. The garden also houses a small zoo and offers scenic views of the Bay of Algiers. It's considered one of the most important botanical gardens in the world.");
                venueTypeText.setText("Garden");
                typeOfViewText.setText("The view from the Jardin d'Essai du Hamma offers a lush, panoramic scene filled with tropical and Mediterranean greenery, framed by the backdrop of Algiers' white architecture and the nearby bay. It's a peaceful oasis blending nature with city charm.");
            }
            isTranslated = !isTranslated;
        });
    }
}